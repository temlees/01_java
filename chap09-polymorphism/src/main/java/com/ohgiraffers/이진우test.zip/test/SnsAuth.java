package main.java.com.ohgiraffers.test;

public interface SnsAuth {



boolean auth(MemberDTO memberDTO);
}
